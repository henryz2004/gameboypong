/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 end_screen end_screen.png 
 * Time-stamp: Wednesday 04/05/2023, 00:32:50
 * 
 * Image Information
 * -----------------
 * end_screen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef END_SCREEN_H
#define END_SCREEN_H

extern const unsigned short end_screen[38400];
#define END_SCREEN_SIZE 76800
#define END_SCREEN_LENGTH 38400
#define END_SCREEN_WIDTH 240
#define END_SCREEN_HEIGHT 160

#endif

