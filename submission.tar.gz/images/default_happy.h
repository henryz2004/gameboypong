/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 default_happy default_happy.png 
 * Time-stamp: Wednesday 04/05/2023, 00:02:08
 * 
 * Image Information
 * -----------------
 * default_happy.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEFAULT_HAPPY_H
#define DEFAULT_HAPPY_H

extern const unsigned short default_happy[144];
#define DEFAULT_HAPPY_SIZE 288
#define DEFAULT_HAPPY_LENGTH 144
#define DEFAULT_HAPPY_WIDTH 12
#define DEFAULT_HAPPY_HEIGHT 12

#endif

