/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 poopyocean poopyocean.png 
 * Time-stamp: Tuesday 04/04/2023, 05:41:04
 * 
 * Image Information
 * -----------------
 * poopyocean.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef POOPYOCEAN_H
#define POOPYOCEAN_H

extern const unsigned short poopyocean[38400];
#define POOPYOCEAN_SIZE 76800
#define POOPYOCEAN_LENGTH 38400
#define POOPYOCEAN_WIDTH 240
#define POOPYOCEAN_HEIGHT 160

#endif

