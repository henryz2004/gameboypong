/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 default_cube default_cube.png 
 * Time-stamp: Wednesday 04/05/2023, 00:01:59
 * 
 * Image Information
 * -----------------
 * default_cube.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEFAULT_CUBE_H
#define DEFAULT_CUBE_H

extern const unsigned short default_cube[144];
#define DEFAULT_CUBE_SIZE 288
#define DEFAULT_CUBE_LENGTH 144
#define DEFAULT_CUBE_WIDTH 12
#define DEFAULT_CUBE_HEIGHT 12

#endif

