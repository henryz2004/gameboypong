/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 default_wink default_wink.png 
 * Time-stamp: Wednesday 04/05/2023, 00:02:34
 * 
 * Image Information
 * -----------------
 * default_wink.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEFAULT_WINK_H
#define DEFAULT_WINK_H

extern const unsigned short default_wink[144];
#define DEFAULT_WINK_SIZE 288
#define DEFAULT_WINK_LENGTH 144
#define DEFAULT_WINK_WIDTH 12
#define DEFAULT_WINK_HEIGHT 12

#endif

