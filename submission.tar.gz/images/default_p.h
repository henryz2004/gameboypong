/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 default_p default_p.png 
 * Time-stamp: Wednesday 04/05/2023, 00:02:24
 * 
 * Image Information
 * -----------------
 * default_p.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEFAULT_P_H
#define DEFAULT_P_H

extern const unsigned short default_p[144];
#define DEFAULT_P_SIZE 288
#define DEFAULT_P_LENGTH 144
#define DEFAULT_P_WIDTH 12
#define DEFAULT_P_HEIGHT 12

#endif

