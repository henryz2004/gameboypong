/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 background_start background_start.png 
 * Time-stamp: Wednesday 04/05/2023, 00:39:19
 * 
 * Image Information
 * -----------------
 * background_start.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND_START_H
#define BACKGROUND_START_H

extern const unsigned short background_start[38400];
#define BACKGROUND_START_SIZE 76800
#define BACKGROUND_START_LENGTH 38400
#define BACKGROUND_START_WIDTH 240
#define BACKGROUND_START_HEIGHT 160

#endif

