/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 default_hit default_hit.png 
 * Time-stamp: Wednesday 04/05/2023, 00:02:16
 * 
 * Image Information
 * -----------------
 * default_hit.png 12@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DEFAULT_HIT_H
#define DEFAULT_HIT_H

extern const unsigned short default_hit[144];
#define DEFAULT_HIT_SIZE 288
#define DEFAULT_HIT_LENGTH 144
#define DEFAULT_HIT_WIDTH 12
#define DEFAULT_HIT_HEIGHT 12

#endif

