#ifndef TRIGTABLE_H
#define TRIGTABLE_H

extern const short sin_[3600];
extern const short cos_[3600];

#endif